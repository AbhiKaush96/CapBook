import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CapbookService } from './services/capbook.service';
import { Message } from './signup/Message';
import { Person } from './signup/Person';
import { Notif } from './notif';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'CAP BOOK';
  authority:string;
  message:Message;
  emailId:string;
  _friendRequests:Person[];
  notif:Notif[];
  constructor(private route:Router,private capbookService:CapbookService){
    
  }
  ngOnInit(){
    if(localStorage.getItem('user')){
    this.authority='user';
    }
    this.emailId= JSON.parse(localStorage.getItem('user'));
    console.log(this.emailId);
    
  }
  logout():void{
    localStorage.removeItem('user');
    window.location.reload();
    this.capbookService.logOut(this.emailId).subscribe(
      temp=>{this.message=temp

      }
    )
  }
  
 
}
