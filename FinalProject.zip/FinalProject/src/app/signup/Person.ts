import { PersonInfo } from "./PersonInfo";

export interface Person {
    emailId:string,
    firstName:string,
    lastName:string,
    phoneNo:number,
    dateOfBirth:string,
    gender:string,
    password:string;
    personInfo:PersonInfo
    securityQuestion:string
    online:boolean
}