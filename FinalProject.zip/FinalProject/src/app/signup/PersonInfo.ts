export interface PersonInfo {
    workPlace:string,
    highestQualification:string,
    maritalStatus:string,
    location:string,
    jobStatus:string,
    bloodGroup:string
}