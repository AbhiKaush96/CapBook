export interface Message{
    message:string;
}