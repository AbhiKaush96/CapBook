import { Component, OnInit } from '@angular/core';
import { Person } from './Person';
import { CapbookService } from '../services/capbook.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  public pageTitle:string="SignUp"
  public user:Person;
  public message:string;
  constructor(private capBookService:CapbookService,private router:Router) { }

  ngOnInit() {
  }
  onSubmit(user:Person){
    
    this.capBookService.acceptUserDetails(user).subscribe(
      user =>{
        this.user=user;
        if(user)
        this.router.navigate(['/login'])
        else
        this.message='User Already Exists!!!'
        this.ngOnInit();
      }
          
    );

    }}
