import { Component, OnInit } from '@angular/core';
import { Person } from '../signup/Person';
import { CapbookService } from '../services/capbook.service';
import { Router } from '@angular/router';
import { Message } from '../signup/Message';
import { PersonInfo } from '../signup/PersonInfo';

@Component({
  selector: 'app-update-profile',
  templateUrl: './update-profile.component.html',
  styleUrls: ['./update-profile.component.css']
})
export class UpdateProfileComponent implements OnInit {
  emailId:string
  message:Message
  person:Person
  constructor(private capbookServices:CapbookService,private router:Router) { }

  ngOnInit() {
    if(!localStorage.getItem('user'))
    this.router.navigate(['/home']);
      this.emailId= JSON.parse(localStorage.getItem('user'));
      console.log(this.emailId)
  }
  onSubmit(personInfo:PersonInfo){
    this.capbookServices.editUserDetails(personInfo,this.emailId).subscribe(
      tempFriends=>{
               this.message=tempFriends;
               this.router.navigate(['/myProfile']);
      }
    )
  }
}
