export interface Chat{
    receiverEmail:string;
    senderEmail:string;
    textMessage:string
}