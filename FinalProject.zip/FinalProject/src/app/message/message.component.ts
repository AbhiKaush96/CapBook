import { Component, OnInit } from '@angular/core';
import { ActivatedRoute,Router } from '@angular/router';
import { CapbookService } from '../services/capbook.service';
import { Chat } from './Chat';

@Component({
  selector: 'app-message',
  templateUrl: './message.component.html',
  styleUrls: ['./message.component.css']
})
export class MessageComponent implements OnInit {
emailId:string;
fEmailId:string;
_statusAssign:string;
chats:Chat[]
  constructor(private router:Router,private route:ActivatedRoute,private capbookService:CapbookService) { }

  ngOnInit() {
    var id = this.route.snapshot.paramMap.get('id');
    this.fEmailId = id;
    this.emailId= JSON.parse(localStorage.getItem('user'));
    this.capbookService.getAllMessages(this.emailId,this.fEmailId).subscribe(
      temp =>{
               this.chats=temp
      }
    )
  }
  statusAssign(status:string):void{
    this._statusAssign=status;
    this.capbookService.sendmessageDetails(this.emailId,this._statusAssign,this.fEmailId).subscribe();
    window.location.reload();
    
    
       
  }
}
