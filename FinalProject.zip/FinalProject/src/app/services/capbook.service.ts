import { Injectable } from '@angular/core';
import { Person } from '../signup/Person';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import {map, catchError } from 'rxjs/operators'
import { Message } from '../signup/Message';
import { Post } from '../myProfile/Post';
import { Notif } from '../notif';
import { PersonInfo } from '../signup/PersonInfo';
import { Password } from '../myProfile/Password';
import { Forgot } from '../login/Forgot';

@Injectable({
  providedIn: 'root'
})
export class CapbookService {
  constructor(private httpClient:HttpClient) {
   }
   public getProfilePic(emailId:string):Observable<any>{
    let params=new HttpParams();
      params=params.set('emailId',emailId.toString());
     
    return this.httpClient.get<any>("",{params:params}).pipe(catchError(this.handleError));
  }
  public acceptUserDetails(user:Person):Observable<Person>{
    return this.httpClient.post<Person>("http://localhost:1997/signUp",JSON.parse(JSON.stringify(user))).pipe(catchError(this.handleError));
  }
  public setNewPassword(password:Password,emailId:string):Observable<any>{
    let params=new HttpParams();
    console.log(password.newPassword)
    params=params.set('oldPassword',password.oldPassword);
    params=params.set('newPassword',password.newPassword);
    params=params.set('emailId',emailId);
    
    return this.httpClient.get<any>("http://localhost:1997/changePassword",{params:params}).pipe(catchError(this.handleError));
  }
  public editUserDetails(user:PersonInfo,emailId:string):Observable<Message>{
    let params=new HttpParams();
    params=params.set('emailId',emailId.toString());
    params=params.set('workPlace',user.workPlace);
    params=params.set('highestQualification',user.highestQualification);
    params=params.set('maritalStatus',user.maritalStatus);
    params=params.set('location',user.location);
    params=params.set('jobStatus',user.jobStatus);
    params=params.set('bloodGroup',user.bloodGroup);
    return this.httpClient.get<Message>("http://localhost:1997/personInfo",{params:params}).pipe(catchError(this.handleError));
  }
  public checkLoginDetails(emailId:string,password:string):Observable<Person>{
    let params=new HttpParams();
      params=params.set('emailId',emailId.toString());
      params=params.set('password',password.toString());
    return this.httpClient.get<Person>("http://localhost:1997/login",{params:params}).pipe(catchError(this.handleError));
  }
  public sendComment(comment:string,postId:number,emailId:string){
    let params=new HttpParams();
    params=params.set('comment',comment.toString());
    params=params.set('emailId',emailId.toString());
    
    return this.httpClient.post("http://localhost:1997/login",postId,{params:params}).pipe(catchError(this.handleError));

  }
  public getUserDetails(emailId:string):Observable<Person>{
    let params=new HttpParams();
      params=params.set('emailId',emailId.toString());
     
    return this.httpClient.get<Person>("http://localhost:1997/getUserDetails",{params:params}).pipe(catchError(this.handleError));
  }
  public getAllUsersDetails(emailId:string): Observable<Person[]>{
    let params=new HttpParams();
      params=params.set('emailId',emailId.toString());
    return this.httpClient.get<Person[]>("http://localhost:1997/findNewFriends",{params:params}).pipe(catchError(this.handleError));
  }
  public sendFriendRequest(requesterEmailId:string,friendEmailId:string):Observable<any>{
    let params=new HttpParams();
      params=params.set('requesterEmailId',requesterEmailId.toString());
      params=params.set('friendEmailId',friendEmailId.toString());
      console.log(requesterEmailId,friendEmailId)
    return this.httpClient.get<any>("http://localhost:1997/friendRequest",{params:params}).pipe(catchError(this.handleError));
  }

  public acceptFriendRequest(approverEmailId:string,friendEmailId:string):Observable<Message>{
    let params=new HttpParams();
      params=params.set('approverEmailId',approverEmailId.toString());
      params=params.set('friendEmailId',friendEmailId.toString());
    return this.httpClient.get<Message>("http://localhost:1997/acceptFriendRequest",{params:params}).pipe(catchError(this.handleError));
  }
  public sendPostDetails(emailId:string,message:string):Observable<any>{
    let params=new HttpParams();
      params=params.set('emailId',emailId.toString());
      params=params.set('message',message.toString());
    return this.httpClient.get<any>("http://localhost:1997/sendPost",{params:params}).pipe(catchError(this.handleError));
  }
  public getAllPosts(emailId:string):Observable<Post[]>{
    let params=new HttpParams();
      params=params.set('emailId',emailId.toString());
      
    return this.httpClient.get<Post[]>("http://localhost:1997/getAllPosts",{params:params}).pipe(catchError(this.handleError));
  }
  public getAllNotifications(emailId:string):Observable<Notif[]>{
    let params=new HttpParams();
      params=params.set('emailId',emailId.toString());
      
    return this.httpClient.get<Notif[]>("http://localhost:1997/getNotifications",{params:params}).pipe(catchError(this.handleError));
  }
  public rejectFriendRequest(approverEmailId:string,friendEmailId:string):Observable<Message>{
    let params=new HttpParams();
      params=params.set('rejecterEmailId',approverEmailId.toString());
      params=params.set('friendEmailId',friendEmailId.toString());
    return this.httpClient.get<Message>("http://localhost:1997/deleteFriendRequest",{params:params}).pipe(catchError(this.handleError));
  }
  public getAllFriends(emailId:string):Observable<Person[]>{
    let params=new HttpParams();
      params=params.set('emailId',emailId.toString());
      return this.httpClient.get<Person[]>("http://localhost:1997/findFriends",{params:params}).pipe(catchError(this.handleError));
  }
  
  public getFriendRequests(emailId:string):Observable<Person[]>{
    let params=new HttpParams();
      params=params.set('emailId',emailId.toString());
      return this.httpClient.get<Person[]>("http://localhost:1997/findFriendRequests",{params:params}).pipe(catchError(this.handleError));
  }
  public getFriendSuggestions(emailId:string):Observable<Person[]>{
    let params=new HttpParams();
      params=params.set('emailId',emailId.toString());
      return this.httpClient.get<Person[]>("http://localhost:1997/suggestedFriends",{params:params}).pipe(catchError(this.handleError));
  }

public uploadProfilePicture(fd:FormData,emailId:string):any{
  let params=new HttpParams();
  params=params.set('emailId',emailId.toString());
  return this.httpClient.post("http://localhost:1997/uploadProfilePicture",fd,{params:params}).pipe(catchError(this.handleError));
}
public sendmessageDetails(emailId:string,message:string,femailId:string):any{
  let params=new HttpParams();
  params=params.set('senderEmail',emailId.toString());
  params=params.set('receiverEmail',femailId.toString());
  params=params.set('textMessage',message.toString());
  console.log(message);
  return this.httpClient.get("http://localhost:1997/saveChat",{params:params}).pipe(catchError(this.handleError));
}
public getAllMessages(emailId:string,fEmailId:string):any{
  let params=new HttpParams();
  params=params.set('email',emailId.toString());
  params=params.set('friendEmail',fEmailId.toString());
  return this.httpClient.get("http://localhost:1997/getChat",{params:params}).pipe(catchError(this.handleError));

}
public getMyPosts(emailId:string):Observable<Post[]>{
  let params=new HttpParams();
      params=params.set('emailId',emailId.toString());
      return this.httpClient.get<Post[]>("http://localhost:1997/myPosts",{params:params}).pipe(catchError(this.handleError));
}
public forgotPassword(password:Forgot):Observable<Message>{
  let params=new HttpParams();
      params=params.set('emailId',password.emailId)
      params=params.set('securityQuestion',password.securityQuestion)
      params=params.set('password',password.newPassword)
      return this.httpClient.get<Message>("http://localhost:1997/forgotPassword",{params:params}).pipe(catchError(this.handleError));
}

public logOut(emailId:string):Observable<Message>{
  let params=new HttpParams();
      params=params.set('emailId',emailId.toString());
      return this.httpClient.get<Message>("http://localhost:1997/logout",{params:params}).pipe(catchError(this.handleError));
}
private handleError(error:any){
  if(error instanceof ErrorEvent){
    console.error(`1 An ErrorEvent occurred:`,error.error.message);

    return throwError(error.error.message);
  } else if(error instanceof HttpErrorResponse){
    console.error(`2 Backend returned code ${error.status}, body was: ${error.message}`);
    return throwError(`Backend returned code ${error.status}, body was: ${error.message}`); 
  }  else if(error instanceof TypeError){
    console.error(`3 TypeError has occurred ${error.message}, body was ${error.stack} `);
    return throwError(`TypeError has occurred ${error.message}, body was ${error.stack} `);
  }
}

}
