export interface Forgot{
    emailId:string
    securityQuestion:string;
    newPassword:string;
    }