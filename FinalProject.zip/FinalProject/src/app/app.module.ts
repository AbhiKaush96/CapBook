import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { FriendsComponent } from './friends/friends.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { MyfriendsComponent } from './myfriends/myfriends.component';
import { CapbookService } from './services/capbook.service';
import { MyProfileComponent } from './myProfile/my-profile.component';
import { HomeComponent } from './home/home.component';
import { UpdateProfileComponent } from './updateProfile/update-profile.component';
import { MessageComponent } from './message/message.component';





@NgModule({
  declarations: [
    AppComponent,
    MyProfileComponent,
    LoginComponent,
    FriendsComponent,
    SignupComponent,
    MyfriendsComponent,
    HomeComponent,
    UpdateProfileComponent,
    MessageComponent,
   
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot([
      { path: '', redirectTo: 'home', pathMatch: 'full'},
      {path: 'home',component:HomeComponent},
      { path: 'login', component: LoginComponent },  
      { path: 'signUp', component: SignupComponent },
      { path: 'friends', component: FriendsComponent },
      { path: 'myfriends', component: MyfriendsComponent},
      { path: 'myProfile', component: MyProfileComponent},
      { path: 'updateProfile', component: UpdateProfileComponent},
      { path: 'message/:id', component: MessageComponent}
    ])
  ],
  providers: [CapbookService],
  bootstrap: [AppComponent]
})
export class AppModule { }
