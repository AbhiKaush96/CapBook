export interface Notif{
    emailId:string;
    message:string;
   
}