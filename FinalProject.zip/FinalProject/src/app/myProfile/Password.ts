export interface Password{
oldPassword:string;
newPassword:string;
}