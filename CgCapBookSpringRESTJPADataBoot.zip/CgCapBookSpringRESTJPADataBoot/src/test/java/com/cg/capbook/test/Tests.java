package com.cg.capbook.test;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import com.cg.capbook.beans.Person;
import com.cg.capbook.dao.PersonDAO;
import com.cg.capbook.exceptions.UserDetailsNotFoundException;
import com.cg.capbook.services.UserServices;

public class Tests {
	@MockBean
	private PersonDAO personDAO;
	@Autowired
	private UserServices userServices;
	private Person person1,person2;
	@Before
	public void setUpData() {
		person1 = new Person("shravan@gmail.com","abcd1234","Shravan", "Marutha",1234567890L,"Male","23/07/1997","mom",false);
		person2= new Person("charan@gmail.com","abcd1234","Charan", "Kothuri",1234567891L,"Male","30/03/1996","mom",false);
	}
	@Test
	public void a() throws UserDetailsNotFoundException{
		Mockito.when(personDAO.save(Mockito.any(Person.class))).thenReturn(person1);
		Person check=userServices.signUp(person1);
		assertThat("shravan@gmail.com").isEqualTo(check.getEmailId());	
	}
}
