package com.cg.capbook.dao;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.capbook.beans.Person;

public interface PersonDAO extends JpaRepository<Person,String>{
	@Query("select a from Person a where not a.emailId=:emailId")
	ArrayList<Person> findNewFriends(@Param("emailId") String emailId);
	@Transactional
	@Modifying
	@Query("delete  from Person a where a.emailId=:emailId")
	void deleteUser(@Param("emailId") String emailId);
}
