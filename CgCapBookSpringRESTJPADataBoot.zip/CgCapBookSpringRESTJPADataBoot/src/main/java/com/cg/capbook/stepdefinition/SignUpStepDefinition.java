package com.cg.capbook.stepdefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.capbook.testcasebeans.SignUpPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SignUpStepDefinition {
	private WebDriver driver;
	private SignUpPage page;
	@Given("^User is on signUpPage for creating CapBook account$")
	public void user_is_on_signUpPage_for_creating_CapBook_account() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:4574/signup");
		page=PageFactory.initElements(driver, SignUpPage.class);
	}

	@When("^Clicked on 'Sign Up'$")
	public void clicked_on_Sign_Up() throws Throwable {
	}

	@When("^enters valid details in Sign Up$")
	public void enters_valid_details_in_Sign_Up() throws Throwable {
	}

	@Then("^Displays 'Sign Up Successful Page'$")
	public void displays_Sign_Up_Successful_Page() throws Throwable {
	}

	@When("^does not entered any details$")
	public void does_not_entered_any_details() throws Throwable {
	}

	@Then("^Displays 'Alert box with no username'$")
	public void displays_Alert_box_with_no_username() throws Throwable {
	}

	@When("^entered invalid 'Email ID'$")
	public void entered_invalid_Email_ID() throws Throwable {
	}

	@Then("^Displays 'Alert box with invalid emailId'$")
	public void displays_Alert_box_with_invalid_emailId() throws Throwable {
	}

	@When("^entered invalid 'First Name'$")
	public void entered_invalid_First_Name() throws Throwable {
	}

	@Then("^Displays 'Alert box with invalid firstName'$")
	public void displays_Alert_box_with_invalid_firstName() throws Throwable {
	}

	@When("^entered invalid 'Last Name'$")
	public void entered_invalid_Last_Name() throws Throwable {
	}

	@Then("^Displays 'Alert box with invalid lastName'$")
	public void displays_Alert_box_with_invalid_lastName() throws Throwable {
	}

	@When("^entered invalid 'Phone No'$")
	public void entered_invalid_Phone_No() throws Throwable {
	}

	@Then("^Displays 'Alert box with invalid phoneNo'$")
	public void displays_Alert_box_with_invalid_phoneNo() throws Throwable {
	}

	@When("^entered invalid 'Password'$")
	public void entered_invalid_Password() throws Throwable {
	}

	@Then("^Displays 'Alert box with invalid password'$")
	public void displays_Alert_box_with_invalid_password() throws Throwable {
	}


}
