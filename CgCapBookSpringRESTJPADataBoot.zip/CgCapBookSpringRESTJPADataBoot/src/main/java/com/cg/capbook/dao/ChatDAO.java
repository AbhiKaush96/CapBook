package com.cg.capbook.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.capbook.beans.Chat;

public interface ChatDAO extends JpaRepository<Chat, Integer> {
	@Query("Select a from Chat a where a.senderEmail=:email  and a.receiverEmail=:friendEmail")
	List<Chat> getSenderMessages (@Param("email") String email,@Param("friendEmail") String friendEmail);
	@Query("Select a from Chat a where a.senderEmail=:friendEmail  and a.receiverEmail=:email")
	List<Chat> getReceiverMessages (@Param("email") String email,@Param("friendEmail") String friendEmail);
}
