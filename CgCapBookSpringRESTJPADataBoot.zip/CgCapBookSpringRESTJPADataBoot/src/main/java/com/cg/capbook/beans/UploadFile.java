
package com.cg.capbook.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
@Entity
public class UploadFile {
	@Id
	private String emailId;

	@Lob 
	@Column(name = "FILE_DATA")
	private byte[] data;

	public UploadFile() {
		super();
	}

	public UploadFile(String emailId, byte[] data) {
		super();
		this.emailId = emailId;
		this.data = data;
	}

	//getters and setters
	
	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public byte[] getData() {
		return data;
	}

	public void setData(byte[] data) {
		this.data = data;
	}

}
