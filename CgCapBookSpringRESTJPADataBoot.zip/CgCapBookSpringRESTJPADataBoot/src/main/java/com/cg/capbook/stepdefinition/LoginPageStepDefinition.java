package com.cg.capbook.stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginPageStepDefinition {
	@Given("^user is on 'loginPage' of CapBook$")
	public void user_is_on_loginPage_of_CapBook() throws Throwable {
	}

	@When("^user enters correct 'userName' and wrong 'password'$")
	public void user_enters_correct_userName_and_wrong_password() throws Throwable {
	}

	@Then("^alertbox is created with message 'wrong password entered'$")
	public void alertbox_is_created_with_message_wrong_password_entered() throws Throwable {
	}

	@When("^user enters wrong 'userName' and correct 'password'$")
	public void user_enters_wrong_userName_and_correct_password() throws Throwable {
	}

	@Then("^alertbox is created with message 'wrong username entered'$")
	public void alertbox_is_created_with_message_wrong_username_entered() throws Throwable {
	}

	@When("^user enters wrong 'userName' and wrong'password'$")
	public void user_enters_wrong_userName_and_wrong_password() throws Throwable {
	}

	@Then("^alertbox is created with message 'wrong username and password entered'$")
	public void alertbox_is_created_with_message_wrong_username_and_password_entered() throws Throwable {
	}

	@When("^user enters correct 'userName' and correct 'password'$")
	public void user_enters_correct_userName_and_correct_password() throws Throwable {
	}

	@Then("^user is redirected to \"([^\"]*)\"$")
	public void user_is_redirected_to(String arg1) throws Throwable {
	}
}
