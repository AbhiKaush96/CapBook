package com.cg.capbook.beans;

public class Message {   //Wrapper class to send messages in JSON format

	private String message;

	public Message() {
		super();
	}

	public Message(String message) {
		super();
		this.message = message;
	}

	//getters and setters
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	

	
}
