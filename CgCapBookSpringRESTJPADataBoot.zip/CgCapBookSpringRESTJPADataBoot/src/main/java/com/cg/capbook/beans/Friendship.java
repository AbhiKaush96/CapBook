package com.cg.capbook.beans;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;
@Entity
@IdClass(FriendshipId.class)      
public class Friendship implements Serializable {
	 
	private static final long serialVersionUID = 1L;
	    @Id
	    @ManyToOne
	    @JoinColumn(referencedColumnName = "emailId")  //emailId referenced from Person class
	    private Person requester;        //Person who request the friend request
	    @Id
	    @ManyToOne 
	    @JoinColumn(referencedColumnName = "emailId")  //emailId referenced from Person class
	    private Person friend;         //Person who gets the request
	    private boolean isAccepted;   //true when friend accepts the request
	    
	
		public Friendship() {       //default constructor
			super();
		}
		public Friendship(Person requester, Person friend, boolean isAccepted) {       //parameterized constructor
			super();
			this.requester = requester;
			this.friend = friend;
			this.isAccepted = isAccepted;
		}
		//  getters and setters
	
		@JsonIgnore                              
		public Person getRequester() {
			return requester;
		}
		public void setRequester(Person requester) {
			this.requester = requester;
		}
		@JsonIgnore
		public Person getFriend() {
			return friend;
		}
		public void setFriend(Person friend) {
			this.friend = friend;
		}
		public boolean isAccepted() {
			return isAccepted;
		}
		public void setAccepted(boolean isAccepted) {
			this.isAccepted = isAccepted;
		}
	    
}
