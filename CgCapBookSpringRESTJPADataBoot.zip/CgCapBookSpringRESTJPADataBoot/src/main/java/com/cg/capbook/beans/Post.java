package com.cg.capbook.beans;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;


@Entity
public class Post implements Comparable<Post>{
	@Id
	@GeneratedValue
	private int postId;
	private String emailId;
	private String message;
	private Date time;
	public Post() {
		super();
	}
		

	public Post(String emailId, String message, Date time) {
		super();
		this.emailId = emailId;
		this.message = message;
		this.time = time;
	}

	//getters and setters
	
	public int getPostId() {
		return postId;
	}
	public void setPostId(int postId) {
		this.postId = postId;
	}
	

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}


	public Date getTime() {
		return time;
	}


	public void setTime(Date time) {
		this.time = time;
	}

	public String getEmailId() {
		return emailId;
	}


	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	//To sort collection objects based on time
	
	@Override
	public int compareTo(Post post) {
		return post.getTime().compareTo(getTime());
	}
	
}
