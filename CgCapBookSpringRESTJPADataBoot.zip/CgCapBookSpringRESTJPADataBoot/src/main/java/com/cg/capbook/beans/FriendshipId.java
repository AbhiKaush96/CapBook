package com.cg.capbook.beans;

import java.io.Serializable;

public class FriendshipId implements Serializable{   //Id class for composite key
	private static final long serialVersionUID = 1L;
	private String requester;         //requester emailId
	private String friend;          //friend emailId 
	
	public FriendshipId() {
		super();
	}
	
	public FriendshipId(String requester, String friend) {
		super();
		this.requester = requester;
		this.friend = friend;
	}
	
	//getters and setters
	public String getRequester() {
		return requester;
	}

	public void setRequester(String requester) {
		this.requester = requester;
	}

	public String getFriend() {
		return friend;
	}

	public void setFriend(String friend) {
		this.friend = friend;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((friend == null) ? 0 : friend.hashCode());
		result = prime * result + ((requester == null) ? 0 : requester.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FriendshipId other = (FriendshipId) obj;
		if (friend == null) {
			if (other.friend != null)
				return false;
		} else if (!friend.equals(other.friend))
			return false;
		if (requester == null) {
			if (other.requester != null)
				return false;
		} else if (!requester.equals(other.requester))
			return false;
		return true;
	}


	
}
