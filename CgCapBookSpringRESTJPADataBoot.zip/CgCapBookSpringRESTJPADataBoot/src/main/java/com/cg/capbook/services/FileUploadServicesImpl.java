package com.cg.capbook.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import com.cg.capbook.beans.UploadFile;
import com.cg.capbook.dao.UploadFileDAO;
import com.cg.capbook.exceptions.UserDetailsNotFoundException;
@Component(value="fileUploadServices")
public class FileUploadServicesImpl implements FileUploadServices{
	
	@Autowired
	private UploadFileDAO uploadFileDAO;
	@Autowired
	private UserServices userServices;
	@Override  
	public void uploadProfilePicture(CommonsMultipartFile image, String emailId) throws UserDetailsNotFoundException {
		userServices.getPersonDetails(emailId);
		if (image != null) {             
			CommonsMultipartFile file = image;   //storing image into multipartFile if present 
			UploadFile uploadFile = new UploadFile();
			uploadFile.setData(file.getBytes());
			uploadFile.setEmailId(emailId);
			uploadFileDAO.save(uploadFile); //save image into database
		}		
	}

	@Override  
	public byte[] getProfilePicture(String emailId) throws UserDetailsNotFoundException {
		userServices.getPersonDetails(emailId);
		UploadFile uploadFile = uploadFileDAO.getFile(emailId);  //get profile picture based on emailId
		byte[] imagefiles = uploadFile.getData();
		return imagefiles;
	}
}
