package com.cg.capbook.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.capbook.beans.Message;
import com.cg.capbook.beans.Person;
import com.cg.capbook.exceptions.UserDetailsNotFoundException;
import com.cg.capbook.services.UserServices;

@RestController
@CrossOrigin
public class FriendshipController {
	@Autowired
	UserServices userServices;
	
	@RequestMapping(value="/friendRequest",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Message> friendRequest(@RequestParam("requesterEmailId") String requesterEmailId,@RequestParam("friendEmailId") String friendEmailId){
			try {
				userServices.friendRequest(requesterEmailId, friendEmailId);
				Message message = new Message("Friend request sent successfully");
				return new ResponseEntity<>(message,HttpStatus.OK);
			} catch (UserDetailsNotFoundException e) {
				return null;
			}
	}
	
	@RequestMapping(value="/acceptFriendRequest",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Message> acceptFriendRequest(@RequestParam("approverEmailId") String approverEmailId,@RequestParam("friendEmailId") String friendEmailId){

			try {
				userServices.acceptFriendRequest(approverEmailId, friendEmailId);
				Message message = new Message("Friend request accepted successfully");
				return new ResponseEntity<>(message,HttpStatus.OK);
			} catch (UserDetailsNotFoundException e) {
				return null;
			}	
	}
	
	@RequestMapping(value="/findFriends",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json")
	public ResponseEntity<List<Person>> findFriends(@RequestParam("emailId") String emailId) throws UserDetailsNotFoundException{
			List<Person> friends=userServices.friendList(emailId);
			return new ResponseEntity<>(friends,HttpStatus.OK);
	}
	
	@RequestMapping(value="/findNewFriends",produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Person>> findNewFriends(@RequestParam("emailId") String emailId) throws UserDetailsNotFoundException{
		List<Person> persons=userServices.findFriends(emailId);
		return new ResponseEntity<>(persons,HttpStatus.OK);
	}
	
	@RequestMapping(value="/findFriendRequests",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json")
	public ResponseEntity<List<Person>> findFriendRequests(@RequestParam("emailId") String emailId) throws UserDetailsNotFoundException{

			List<Person> friendRequests=userServices.friendRequests(emailId);
			return new ResponseEntity<>(friendRequests,HttpStatus.OK);
	}
	
	@RequestMapping(value="/deleteFriendRequest",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Message> deleteFriendRequests(@RequestParam("rejecterEmailId") String rejecterEmailId,@RequestParam("friendEmailId") String friendEmailId) throws UserDetailsNotFoundException{
			userServices.deleteFriendRequest(rejecterEmailId,friendEmailId);
			Message message = new Message("Friend request deleted successfully");
			return new ResponseEntity<>(message,HttpStatus.OK);
	}
	
	@RequestMapping(value="/suggestedFriends",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Person>> suggestedFriends(@RequestParam("emailId") String emailId) throws UserDetailsNotFoundException{
			List<Person>suggestedFriends=userServices.suggetedFriends(emailId);
			return new ResponseEntity<List<Person>>(suggestedFriends,HttpStatus.OK);
	}
	
}