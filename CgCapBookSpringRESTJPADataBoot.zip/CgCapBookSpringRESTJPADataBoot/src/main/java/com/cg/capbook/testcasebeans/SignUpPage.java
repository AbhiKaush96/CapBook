package com.cg.capbook.testcasebeans;

public class SignUpPage {

}
