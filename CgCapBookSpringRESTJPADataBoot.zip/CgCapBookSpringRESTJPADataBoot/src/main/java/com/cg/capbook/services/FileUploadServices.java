package com.cg.capbook.services;

import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.cg.capbook.exceptions.UserDetailsNotFoundException;

public interface FileUploadServices{

	void uploadProfilePicture(CommonsMultipartFile image, String emailId) throws UserDetailsNotFoundException;

	byte[] getProfilePicture(String emailId) throws UserDetailsNotFoundException;

}
