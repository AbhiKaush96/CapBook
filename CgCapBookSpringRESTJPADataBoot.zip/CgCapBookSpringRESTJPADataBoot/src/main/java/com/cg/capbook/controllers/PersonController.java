package com.cg.capbook.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.capbook.beans.PersonInfo;
import com.cg.capbook.beans.Message;
import com.cg.capbook.beans.Notification;
import com.cg.capbook.beans.Person;
import com.cg.capbook.exceptions.IncorrectPasswordException;
import com.cg.capbook.exceptions.InvalidSecurityQuestion;
import com.cg.capbook.exceptions.UserDetailsNotFoundException;
import com.cg.capbook.services.UserServices;

@RestController
@CrossOrigin
public class PersonController {
	@Autowired
	UserServices userServices;

	@RequestMapping(value="/signUp",method=RequestMethod.POST,
			consumes=MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json")
	public ResponseEntity<Person> acceptSignUpDetails(@RequestBody Person person){
		try {
			person=userServices.signUp(person);
			return new ResponseEntity<>(person,HttpStatus.OK);
		} catch (UserDetailsNotFoundException e) {

			return new ResponseEntity<>(null,HttpStatus.OK);
		}
	}
	
	@RequestMapping(value="/login",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Person> checkSignInDetails(@RequestParam("emailId") String emailId,@RequestParam("password") String password){
		try {
			Person person=userServices.SignIn(emailId, password);
			return new ResponseEntity<>(person,HttpStatus.OK);
		} catch (UserDetailsNotFoundException | IncorrectPasswordException e) {
			return null;
		}
	}
	
	@RequestMapping(value="/getUserDetails",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Person> getUserDetails(@RequestParam("emailId") String emailId){
		Person person;
		try {
			person = userServices.getPersonDetails(emailId);
			return new ResponseEntity<>(person,HttpStatus.OK);
		} catch (UserDetailsNotFoundException e) {
			return null;
		}
	}
	
	@RequestMapping(value="/forgotPassword",produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Message> forgetPassword(@RequestParam("emailId") String emailId,@RequestParam("securityQuestion") String securityQuestion,@RequestParam("password") String password) {
		 try {
			userServices.forgotPassword(emailId, securityQuestion, password);
			 Message message=new Message("Password has been changed");
				return new ResponseEntity<>(message,HttpStatus.OK);
		} catch (UserDetailsNotFoundException | InvalidSecurityQuestion e) {
			Message message=new Message(e.getMessage());
			return new ResponseEntity<Message>(message,HttpStatus.OK);
		}
	}
	
	@RequestMapping(value="/changePassword",produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Message> changePassword(@RequestParam("emailId") String emailId,@RequestParam("oldPassword") String oldPassword,@RequestParam("newPassword") String newPassword){
		try {
			userServices.changePassword(emailId, oldPassword, newPassword);
			Message message=new Message("Password has been changed");
			return new ResponseEntity<Message>(message,HttpStatus.OK);
		} catch (UserDetailsNotFoundException | IncorrectPasswordException e) {
			Message message=new Message(e.getMessage());
			return new ResponseEntity<Message>(message,HttpStatus.OK);
		}
	}

	@RequestMapping(value="/deleteUser",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Message> deleteUser(@RequestParam("emailId") String emailId) throws UserDetailsNotFoundException{
		userServices.deleteUser(emailId);
		Message message = new Message("Person deleted successfully");
		return new ResponseEntity<>(message,HttpStatus.OK);
	}
	
	@RequestMapping(value="/getNotifications",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Notification>> getNotifications(@RequestParam("emailId") String emailId) throws UserDetailsNotFoundException{
		List<Notification>notifications=userServices.getAllNotifications(emailId);
		return new ResponseEntity<List<Notification>>(notifications,HttpStatus.OK);
	}
	
	@RequestMapping(value="/logout",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Message> logout(@RequestParam("emailId") String emailId) throws UserDetailsNotFoundException{
		userServices.logout(emailId);
		Message message = new Message("Logged out successfully");
		return new ResponseEntity<Message>(message,HttpStatus.OK);
	}
	
	@RequestMapping(value="/personInfo",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Message> updateExtraInformation(@RequestParam("emailId") String emailId,@RequestParam("workPlace") String workPlace,@RequestParam("highestQualification") String highestQualification,@RequestParam("maritalStatus") String maritalStatus,@RequestParam("location") String location,@RequestParam("jobStatus") String jobStatus,@RequestParam("bloodGroup") String bloodGroup) throws UserDetailsNotFoundException{
		PersonInfo personInfo=new PersonInfo(workPlace, highestQualification, maritalStatus, location, jobStatus, bloodGroup);
		userServices.updateExtraInformation(emailId,personInfo);
		Message message = new Message("Personal Info Updated Succesfully");
		return new ResponseEntity<Message>(message,HttpStatus.OK);
	}
}
