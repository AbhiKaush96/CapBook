package com.cg.capbook.beans;


import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Notification implements Comparable<Notification>{
	@Id
	@GeneratedValue
	private int notificationId;
	private String emailId;
	private String message;
	private Date time;
	
	public Notification() {
		super();
	}

	public Notification(String emailId, String message, Date time) {
		super();
		this.emailId = emailId;
		this.message = message;
		this.time = time;
	}

	//getters and setters
	public int getNotificationId() {
		return notificationId;
	}

	public void setNotificationId(int notificationId) {
		this.notificationId = notificationId;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Date getTime() {
		return time;
	}

	public void setTime(Date time) {
		this.time = time;
	}
	//To sort collection objects based on time
	@Override
	public int compareTo(Notification notification) {
		return notification.getTime().compareTo(getTime());
	}	
}
