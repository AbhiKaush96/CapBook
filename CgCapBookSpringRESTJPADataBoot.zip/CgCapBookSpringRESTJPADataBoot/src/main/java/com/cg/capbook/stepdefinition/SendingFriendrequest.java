package com.cg.capbook.stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SendingFriendrequest {
	@Given("^User is on find New Friends Page$")
	public void user_is_on_find_New_Friends_Page() throws Throwable {
	    
	}

	@When("^User clicks on the add button of the user who he wants to send to$")
	public void user_clicks_on_the_add_button_of_the_user_who_he_wants_to_send_to() throws Throwable {
	   
	}

	@Then("^User can send the friend Request$")
	public void user_can_send_the_friend_Request() throws Throwable {
	}
}
