package com.cg.capbook.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
@Entity
public class Chat {
	@Id
	@GeneratedValue
	private int messageId;
	private String textMessage,senderEmail,receiverEmail;
	public Chat() {
		super();
	}
	
	public Chat(String textMessage, String senderEmail, String receiverEmail) {
		super();
		this.textMessage = textMessage;
		this.senderEmail = senderEmail;
		this.receiverEmail = receiverEmail;
	}

	public int getMessageId() {
		return messageId;
	}
	public void setMessageId(int messageId) {
		this.messageId = messageId;
	}
	public String getTextMessage() {
		return textMessage;
	}
	public void setTextMessage(String textMessage) {
		this.textMessage = textMessage;
	}
	public String getSenderEmail() {
		return senderEmail;
	}
	public void setSenderEmail(String senderEmail) {
		this.senderEmail = senderEmail;
	}
	public String getReceiverEmail() {
		return receiverEmail;
	}
	public void setReceiverEmail(String receiverEmail) {
		this.receiverEmail = receiverEmail;
	}
	
	
}
