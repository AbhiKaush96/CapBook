package com.cg.capbook.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.cg.capbook.beans.Chat;
import com.cg.capbook.services.ChatService;

@RestController
@CrossOrigin
public class ChatController {
	@Autowired
	ChatService chatService;
	@RequestMapping(value="/saveChat",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> friendRequest(@RequestParam("textMessage") String textMessage,@RequestParam("senderEmail") String senderEmail,@RequestParam("receiverEmail") String receiverEmail ){
		chatService.saveMessage(textMessage, senderEmail, receiverEmail);
		return new ResponseEntity<>(HttpStatus.OK);
	}
	@RequestMapping(value="/getChat",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Chat>> getAllPosts(@RequestParam("email") String email,@RequestParam("friendEmail") String friendEmail){
			return new ResponseEntity<>(chatService.getAllMessages(email, friendEmail),HttpStatus.OK);
	}
}
