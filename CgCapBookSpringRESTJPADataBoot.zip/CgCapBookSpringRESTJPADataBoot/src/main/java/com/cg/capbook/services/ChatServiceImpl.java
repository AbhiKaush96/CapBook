package com.cg.capbook.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.capbook.beans.Chat;
import com.cg.capbook.dao.ChatDAO;
@Component(value="chatService")
public class ChatServiceImpl implements ChatService{
@Autowired
ChatDAO chatDAO;
	@Override
	public void saveMessage(String textMessage, String senderEmail, String receiverEmail) {
		Chat message=new Chat(textMessage, senderEmail, receiverEmail);
		chatDAO.save(message);
	}

	@Override
	public List<Chat> getAllMessages(String email, String friendEmail) {
		List<Chat> messages=new ArrayList<Chat>();
		messages.addAll(chatDAO.getSenderMessages(email, friendEmail));
		messages.addAll(chatDAO.getReceiverMessages(email, friendEmail));
		return messages;
	}

}
