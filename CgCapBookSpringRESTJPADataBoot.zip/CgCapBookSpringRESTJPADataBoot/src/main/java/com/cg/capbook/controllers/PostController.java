package com.cg.capbook.controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.cg.capbook.beans.Post;
import com.cg.capbook.exceptions.UserDetailsNotFoundException;
import com.cg.capbook.services.PostServices;
@RestController
@CrossOrigin
public class PostController {
	@Autowired
	PostServices postServices;
	
	@RequestMapping(value="/sendPost",method=RequestMethod.GET)
	public ResponseEntity<String> acceptPostDetails(@RequestParam("emailId")String emailId,@RequestParam("message") String message){
		try {
			postServices.sendPost(emailId, message);
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (UserDetailsNotFoundException e) {
			
			return new ResponseEntity<>(HttpStatus.OK);
		}	
	}
	
	@RequestMapping(value="/myPosts",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Post>> getMyPosts(@RequestParam("emailId")String emailId){
		return new ResponseEntity<>(postServices.myPosts(emailId),HttpStatus.OK);	
	}
	
	@RequestMapping(value="/getAllPosts",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Post>> getAllPosts(@RequestParam("emailId")String emailId){
		try {
			return new ResponseEntity<>(postServices.getAllPosts(emailId),HttpStatus.OK);
		} catch (UserDetailsNotFoundException e) {
			
			return new ResponseEntity<>(HttpStatus.OK);
		}	
	}
}
