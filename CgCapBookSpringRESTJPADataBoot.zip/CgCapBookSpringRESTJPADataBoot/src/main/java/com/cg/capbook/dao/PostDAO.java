package com.cg.capbook.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.capbook.beans.Person;
import com.cg.capbook.beans.Post;

public interface PostDAO extends JpaRepository<Post, Integer> {
	@Query("SELECT p from Post p where p.emailId=:emailId")
	List<Post> getMyPosts(@Param("emailId")String emailId);

}
