package com.cg.capbook.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.capbook.beans.Friendship;
import com.cg.capbook.beans.Person;

public interface FriendshipDAO extends JpaRepository<Friendship,Person>{
	@Query("select a.requester from Friendship a where a.friend=:person AND a.isAccepted is true")
	List<Person> findAcceptedFriends(@Param("person") Person person);
	@Query("select a.friend from Friendship a where a.requester=:person AND a.isAccepted is true")
	List<Person> findRequestedFriends(@Param("person") Person person);
	@Query("select a.friend from Friendship a where a.requester=:person AND a.isAccepted is false")
	List<Person> findRequestedFriendsNotApproved(@Param("person") Person person);
	@Query("select a.requester from Friendship a where a.friend=:person AND a.isAccepted is false")
	List<Person>findFriendRequests(@Param("person") Person person);
	@Transactional
	@Modifying
	@Query("delete from Friendship a where a.requester=:friend AND a.friend=:rejecter")
	void deleteFriendRequests(@Param("rejecter") Person approver,@Param("friend") Person friend);
	@Transactional
	@Modifying
	@Query("delete from Friendship a where a.requester=:person OR a.friend=:person")
	void deleteUserAllFriendRequests(@Param("person") Person person);
}
