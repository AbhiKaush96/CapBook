package com.cg.capbook.stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RespondingFriendRequestStepDefinition {
	@Given("^User is on Friend Requests Page$")
	public void user_is_on_Friend_Requests_Page() throws Throwable {
	 
	}

	@When("^User clicks on the accept button of the user who he wants to accept from$")
	public void user_clicks_on_the_accept_button_of_the_user_who_he_wants_to_accept_from() throws Throwable {
	
	}

	@Then("^User can accept the friend Request$")
	public void user_can_accept_the_friend_Request() throws Throwable {
	    
	}

	@When("^User clicks on the reject button of the user who he wants to accept from$")
	public void user_clicks_on_the_reject_button_of_the_user_who_he_wants_to_accept_from() throws Throwable {
	    
	}

	@Then("^User can reject the friend Request$")
	public void user_can_reject_the_friend_Request() throws Throwable {
	  
	}
}
