package com.cg.capbook.stepdefinition;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class HomePageStepDefinition {
	private WebDriver driver;
	@Given("^User is on 'homePage' of CapBook$")
	public void user_is_on_homePage_of_CapBook() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver=new ChromeDriver();
		//driver.get("http://localhost:4574/changePlan");
		
	}

	@When("^user clicks on 'signUp' button$")
	public void user_clicks_on_signUp_button() throws Throwable {
		By signUp=By.name("SignUp");
		WebElement signUpSearchTxt=driver.findElement(signUp);
		signUpSearchTxt.click();
	}

	@Then("^user is redirected to 'signUpPage'$")
	public void user_is_redirected_to_signUpPage() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Registration";
		Assert.assertEquals(expectedTitle,actualTitle);
		driver.close();
	}

	@When("^user clicks on 'login' button$")
	public void user_clicks_on_login_button() throws Throwable {
		By signIn=By.name("SignIn");
		WebElement signInSearchTxt=driver.findElement(signIn);
		signInSearchTxt.click();
	}

	@Then("^user is redirected to 'loginPage'$")
	public void user_is_redirected_to_loginPage() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Login";
		Assert.assertEquals(expectedTitle,actualTitle);
		driver.close();
	}
}
