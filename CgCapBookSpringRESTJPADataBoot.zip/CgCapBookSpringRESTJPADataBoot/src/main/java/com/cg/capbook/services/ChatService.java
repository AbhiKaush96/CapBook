package com.cg.capbook.services;

import java.util.List;

import com.cg.capbook.beans.Chat;

public interface ChatService {
void saveMessage(String textMessage,String senderEmail,String receiverEmail);
List<Chat> getAllMessages(String email,String friendEmail);
}
