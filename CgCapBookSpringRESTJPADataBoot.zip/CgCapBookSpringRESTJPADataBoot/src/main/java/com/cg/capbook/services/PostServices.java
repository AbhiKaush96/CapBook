package com.cg.capbook.services;

import java.util.List;

import com.cg.capbook.beans.Post;
import com.cg.capbook.exceptions.UserDetailsNotFoundException;

public interface PostServices {
	void sendPost(String emailId,String message) throws UserDetailsNotFoundException; 
	List<Post> getAllPosts(String emailId) throws UserDetailsNotFoundException;
	List<Post> myPosts(String emailId);
}
