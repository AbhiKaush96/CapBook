package com.cg.capbook.services;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.capbook.beans.PersonInfo;
import com.cg.capbook.beans.Friendship;
import com.cg.capbook.beans.Notification;
import com.cg.capbook.beans.Person;
import com.cg.capbook.dao.FriendshipDAO;
import com.cg.capbook.dao.NotificationDAO;
import com.cg.capbook.dao.PersonDAO;
import com.cg.capbook.exceptions.*;
@Component(value="userServices")
public class UserServicesImpl implements UserServices{
	@Autowired
	private PersonDAO personDAO;
	@Autowired
	private FriendshipDAO friendDAO;
	@Autowired
	private NotificationDAO notificationDAO;

	@Override
	public Person signUp(Person person) throws UserDetailsNotFoundException {
		if(!personDAO.findById(person.getEmailId()).isPresent()) {
			person.setOnline(false);
			person.setPassword(generateHash(person.getPassword())); //create encrypted password
			person=personDAO.save(person);      //saving new user into database
		}
		else {
			new UserDetailsNotFoundException("Already account exists with same EmailId"); 
		}
		return person;
	}

	@Override
	public Person SignIn(String emailId, String password) throws UserDetailsNotFoundException, IncorrectPasswordException {
		Person person=getPersonDetails(emailId);
		String hashedPassword=generateHash(password);
		if(hashedPassword.compareTo(person.getPassword())==0)	{	
			person.setOnline(true);
			personDAO.save(person);//check sign details and throw exception if anything is incorrect
			return person;
		}
		else throw new IncorrectPasswordException("Incorrect password!!");

	}
	//algorithm for password encryption
	public static String generateHash(String input) {        
		StringBuilder hash = new StringBuilder();
		try {
			MessageDigest sha = MessageDigest.getInstance("SHA-1");
			byte[] hashedBytes = sha.digest(input.getBytes());
			char[] digits = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
					'a', 'b', 'c', 'd', 'e', 'f' };
			for (int idx = 0; idx < hashedBytes.length; ++idx) {
				byte b = hashedBytes[idx];
				hash.append(digits[(b & 0xf0) >> 4]);
				hash.append(digits[b & 0x0f]);
			}
		} catch (NoSuchAlgorithmException e) {
		}
		return hash.toString();
	}

	@Override
	public Boolean changePassword(String emailId, String oldPassword,String newPassword) throws UserDetailsNotFoundException, IncorrectPasswordException {
		Person person=SignIn(emailId, oldPassword);
		person.setPassword(generateHash(newPassword));
		personDAO.save(person);
		return true;
	}

	@Override 
	public List<Person> findFriends(String emailId) throws UserDetailsNotFoundException {
		Person person = getPersonDetails(emailId);
		List<Person> friends= personDAO.findNewFriends(emailId);
		friends.removeAll(friendList(emailId));    //removing already existing friends
		friends.removeAll(friendDAO.findRequestedFriendsNotApproved(person));    //removing requested friends but person not yet approved
		friends.removeAll(friendRequests(emailId)); //removing the requested friends 
		return friends;
	}

	@Override
	public Person getPersonDetails(String emailId) throws UserDetailsNotFoundException {
		Person person=personDAO.findById(emailId).orElseThrow(()->
		new UserDetailsNotFoundException("User Details Not Found With emailId="+emailId));
		return person;
	}


	@Override
	public void friendRequest(String requesterEmailId, String friendEmailId) throws UserDetailsNotFoundException {
		Person requester=getPersonDetails(requesterEmailId);
		Person friend =getPersonDetails(friendEmailId);
		Friendship friendship=new Friendship(requester, friend, false); //finding the friend requests of person
		friendDAO.save(friendship);
	}

	@Override
	public void acceptFriendRequest(String approverEmailId, String friendEmailId) throws UserDetailsNotFoundException {
		Person approver=getPersonDetails(approverEmailId);
		Person friend =getPersonDetails(friendEmailId);
		Friendship friendship=new Friendship(friend, approver, true);  //setting the isAccepted true to make friend
		notificationDAO.save(new Notification(approverEmailId,approver.getEmailId()+" and "+friend.getEmailId()+" are friends now", new Date()));
		notificationDAO.save(new Notification(friendEmailId,approver.getEmailId()+" and "+friend.getEmailId()+" are friends now" , new Date()));
		friendDAO.save(friendship);
	}

	@Override
	public List<Person> friendList(String emailId) throws UserDetailsNotFoundException {
		Person person = getPersonDetails(emailId);
		List<Person> friends = friendDAO.findAcceptedFriends(person);   //finding the friends u accepted for and approved
		friends.addAll(friendDAO.findRequestedFriends(person));  //finding the friends u requested for and approved
		return friends;
	}

	@Override
	public List<Person> friendRequests(String emailId) throws UserDetailsNotFoundException {
		Person person = getPersonDetails(emailId);
		List<Person> friendrequests = friendDAO.findFriendRequests(person);
		return friendrequests;
	}

	@Override
	public Boolean deleteFriendRequest(String rejecterEmailId, String friendEmailId) throws UserDetailsNotFoundException {
		Person friend = getPersonDetails(friendEmailId);
		Person rejecter=getPersonDetails(rejecterEmailId);
		friendDAO.deleteFriendRequests(rejecter,friend);  //rejecting friend request by deleting request from database
		return true;
	}

	@Override
	public Boolean deleteUser(String emailId) throws UserDetailsNotFoundException {
		Person person = getPersonDetails(emailId);
		friendDAO.deleteUserAllFriendRequests(person);
		personDAO.deleteUser(emailId);
		return true;
	}

	@Override
	public List<Notification> getAllNotifications(String emailId) throws UserDetailsNotFoundException {
		List<Notification> notifications =new ArrayList<Notification>();
		for(Person friend:friendList(emailId)) {   
			if(checkBirthday(friend)!=null)     //check friend birthday if any
				notifications.add(checkBirthday(friend));
			notifications.addAll(notificationDAO.getfriendNotifications(friend.getEmailId()));
		}
		for(int i=0;i<notifications.size()-1;i++) {
			for(int j=i+1;j<notifications.size();j++) {
				if(notifications.get(i).getMessage().compareTo(notifications.get(j).getMessage())==0) {
					notifications.remove(i);
				}
			}
		}
		Collections.sort(notifications);
		return notifications;
	}

	//algorithm to check friend birthday
	public static Notification checkBirthday(Person friend) {
		String date=	new SimpleDateFormat("MM-dd").format(new Date());
		if( (friend.getDateOfBirth().substring(5, 10)).compareTo(date)==0) 
			return new Notification(friend.getEmailId(), "Today is "+friend.getEmailId()+" birthday", new Date());
		return null;
	}


	@Override
	public void updateExtraInformation(String emailId,PersonInfo personInfo)
			throws UserDetailsNotFoundException {
		Person person=getPersonDetails(emailId);
		person.setPersonInfo(personInfo);
		personDAO.save(person);	 //updating person info
	}

	@Override
	public List<Person> mutualFriends(String emailId1, String emailId2) throws UserDetailsNotFoundException {
		List<Person> friends1 = friendList(emailId1);
		List<Person> friends2 = friendList(emailId2);
		List<Person> mutualFriends=new ArrayList<>();
		if(!friends1.isEmpty() && !friends2.isEmpty()) {                   //finding out mutual friend by by checking friend list of each
			for(Person friend1:friends1)
			{
				for(Person friend2:friends2)
					if(friend1.equals(friend2)) {
						mutualFriends.add(friend1);
						break;
					}
			}
		}
		return mutualFriends;
	}

	@Override
	public List<Person> nonMutualFriends(String emailId1, String emailId2) throws UserDetailsNotFoundException {
		List<Person> friends1=friendList(emailId1);
		friends1.removeAll(mutualFriends(emailId1, emailId2)); 
		List<Person> friends2 = friendList(emailId2);
		friends2.removeAll(mutualFriends(emailId1, emailId2));
		List<Person> nonMutualFriends=new ArrayList<>();
		nonMutualFriends.addAll(friends1);
		nonMutualFriends.addAll(friends2);
		nonMutualFriends.remove(getPersonDetails(emailId1));          //finding out the non mutual friends and removing the duplicates
		nonMutualFriends.remove(getPersonDetails(emailId2));
		return nonMutualFriends;
	}

	@Override
	public List<Person> suggetedFriends(String emailId) throws UserDetailsNotFoundException {
		List<Person>friends=friendList(emailId);
		List<Person>suggestedPersons=new ArrayList<>();
		for(Person friend:friends) {
			suggestedPersons.addAll(nonMutualFriends(emailId, friend.getEmailId()));
		}
		suggestedPersons.removeAll(friends);  //removing friends from non mutual friends
		for(int i=0;i<suggestedPersons.size()-1;i++) {
			for(int j=i+1;j<suggestedPersons.size();j++) {
				if(suggestedPersons.get(i).getEmailId().compareTo(suggestedPersons.get(j).getEmailId())==0) {
					suggestedPersons.remove(j);
				}
			}
		}
		return suggestedPersons;
	}

	@Override
	public void forgotPassword(String emailId, String securityQuestion, String password) throws UserDetailsNotFoundException, InvalidSecurityQuestion {
		Person person=getPersonDetails(emailId);
		if(person.getSecurityQuestion().compareTo(securityQuestion)==0)  //checking security question and giving authority to user to change password
		{
			person.setPassword(generateHash(password));
			personDAO.save(person);
		}
		else
			throw new InvalidSecurityQuestion("Incorrect security answer");
	}

	@Override
	public void logout(String emailId) throws UserDetailsNotFoundException {
		Person person = getPersonDetails(emailId);
		person.setOnline(false);
		personDAO.save(person);
	}

	@Override
	public List<Person> checkLoginFriends(String emailId) throws UserDetailsNotFoundException {
		List<Person> friends = friendList(emailId);
		List<Person> onlineFriends= new ArrayList<>();
		for(Person friend: friends ) {
			if(friend.isOnline()==true)
				onlineFriends.add(friend);
		}
		return onlineFriends;
	}
}
