package com.cg.capbook.beans;
import javax.persistence.Embeddable;
@Embeddable
public class PersonInfo {
	private String workPlace;
	private String highestQualification;
	private String maritalStatus;
	private String location;
	private String jobStatus;
	private String bloodGroup;

	public PersonInfo() {
		super();
	}

	public PersonInfo(String workPlace, String highestQualification, String maritalStatus, String location,
			String jobStatus, String bloodGroup) {
		super();
		this.workPlace = workPlace;
		this.highestQualification = highestQualification;
		this.maritalStatus = maritalStatus;
		this.location = location;
		this.jobStatus = jobStatus;
		this.bloodGroup = bloodGroup;
	}

	//getters and setters
	
	public String getWorkPlace() {
		return workPlace;
	}

	public void setWorkPlace(String workPlace) {
		this.workPlace = workPlace;
	}

	public String getHighestQualification() {
		return highestQualification;
	}

	public void setHighestQualification(String highestQualification) {
		this.highestQualification = highestQualification;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getJobStatus() {
		return jobStatus;
	}

	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}

	public String getBloodGroup() {
		return bloodGroup;
	}

	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}



}
