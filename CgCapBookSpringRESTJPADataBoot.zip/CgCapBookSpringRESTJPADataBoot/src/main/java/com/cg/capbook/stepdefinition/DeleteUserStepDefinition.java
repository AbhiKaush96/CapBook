package com.cg.capbook.stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class DeleteUserStepDefinition {
	@Given("^User is on settings of his homepage$")
	public void user_is_on_settings_of_his_homepage() throws Throwable {
	    
	}

	@When("^User clicks on the deactivate button$")
	public void user_clicks_on_the_deactivate_button() throws Throwable {
	    
	}

	@Then("^User can no longer see his account$")
	public void user_can_no_longer_see_his_account() throws Throwable {
	   
	}

}
