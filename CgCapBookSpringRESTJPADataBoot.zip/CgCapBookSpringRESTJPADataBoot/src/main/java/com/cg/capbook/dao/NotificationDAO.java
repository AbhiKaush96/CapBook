package com.cg.capbook.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.capbook.beans.Notification;

public interface NotificationDAO extends JpaRepository<Notification, Integer>{
	@Query("select a from Notification a where a.emailId=:emailId")
	List<Notification> getfriendNotifications(@Param("emailId") String emailId);
}
