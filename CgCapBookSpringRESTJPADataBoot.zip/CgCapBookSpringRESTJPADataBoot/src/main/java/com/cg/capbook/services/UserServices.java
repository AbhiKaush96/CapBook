package com.cg.capbook.services;

import java.util.List;
import com.cg.capbook.beans.PersonInfo;
import com.cg.capbook.beans.Notification;
import com.cg.capbook.beans.Person;
import com.cg.capbook.exceptions.IncorrectPasswordException;
import com.cg.capbook.exceptions.InvalidSecurityQuestion;
import com.cg.capbook.exceptions.UserDetailsNotFoundException;

public interface UserServices {
	Person signUp(Person person) throws UserDetailsNotFoundException;
	Person SignIn(String emailId,String password) throws UserDetailsNotFoundException, IncorrectPasswordException;
	Boolean changePassword(String emailId,String oldPassword,String newPassword) throws UserDetailsNotFoundException, IncorrectPasswordException;
	List<Person> findFriends(String emailId) throws UserDetailsNotFoundException;
	Person getPersonDetails(String emailId) throws UserDetailsNotFoundException;
	void friendRequest(String requesterEmailId, String friendEmailId) throws UserDetailsNotFoundException;
	void acceptFriendRequest(String approverEmailId,String friendEmailId) throws UserDetailsNotFoundException;
	List<Person> friendList(String emailId) throws UserDetailsNotFoundException;
	List<Person> friendRequests(String emailId) throws UserDetailsNotFoundException;
	Boolean deleteFriendRequest(String rejecterEmailId,String friendEmailId) throws UserDetailsNotFoundException;
	Boolean deleteUser(String EmailId) throws UserDetailsNotFoundException;
	List<Notification> getAllNotifications(String emailId) throws UserDetailsNotFoundException;
	void updateExtraInformation(String emailId,PersonInfo personInfo) throws UserDetailsNotFoundException;
	List<Person> mutualFriends(String emailId1,String emailId2) throws UserDetailsNotFoundException;
	List<Person> nonMutualFriends(String emailId1,String emailId2) throws UserDetailsNotFoundException;
	List<Person> suggetedFriends(String emailId) throws UserDetailsNotFoundException;
	void forgotPassword(String emailId,String securityQuestion,String password) throws UserDetailsNotFoundException, InvalidSecurityQuestion;
	void logout(String emailId) throws UserDetailsNotFoundException;
	List<Person> checkLoginFriends(String emailId) throws UserDetailsNotFoundException;
}
