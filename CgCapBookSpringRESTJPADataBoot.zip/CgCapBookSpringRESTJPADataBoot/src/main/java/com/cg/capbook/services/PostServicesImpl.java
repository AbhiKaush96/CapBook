package com.cg.capbook.services;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.capbook.beans.Notification;
import com.cg.capbook.beans.Person;
import com.cg.capbook.beans.Post;
import com.cg.capbook.dao.NotificationDAO;
import com.cg.capbook.dao.PostDAO;
import com.cg.capbook.exceptions.UserDetailsNotFoundException;

@Component(value="postServices")
public class PostServicesImpl implements PostServices{
	@Autowired
	PostDAO postDAO;
	@Autowired
	UserServices userServices;
	@Autowired
	NotificationDAO notificationDAO;
	@Override
	public void sendPost(String emailId, String message) throws UserDetailsNotFoundException {
		Post post =new Post(emailId, message,  new Date());
		notificationDAO.save(new Notification(emailId, userServices.getPersonDetails(emailId).getFirstName()+" posted on his timeline on"+new SimpleDateFormat("HH:mm:ss").format(Calendar.getInstance().getTime()), new Date()));
		postDAO.save(post);	 //create new post and notification, save into database
	}
	
	@Override
	public List<Post> getAllPosts(String emailId) throws UserDetailsNotFoundException {
		List<Post> posts=new ArrayList<Post>();
		posts.addAll(myPosts(emailId));
		for(Person friend:userServices.friendList(emailId))
		posts.addAll(myPosts(friend.getEmailId()));
		Collections.sort(posts);   //Sorting posts based on time
		return posts;
	}
	
	@Override    
	public List<Post> myPosts(String emailId) {
		List<Post> myPosts= postDAO.getMyPosts(emailId);
		Collections.sort(myPosts);  //Sorting posts based on time
		return myPosts;
	}
	
}
